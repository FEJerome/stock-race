#!/bin/bash
# 自动恢复脚本 - 在 WSL2 中运行

echo "========================================"
echo "  VM 配置自动恢复"
echo "========================================"
echo ""

BACKUP_DIR="$(cd "$(dirname "$0")" && pwd)"
cd ~

# 1. 恢复 Shell 配置
echo "🔧 [1/8] 恢复 Shell 配置..."
for file in .bashrc .bash_profile .profile .zshrc .zprofile .p10k.zsh; do
    if [ -f "$BACKUP_DIR/$file" ]; then
        if [ -f "$HOME/$file" ]; then
            cp "$HOME/$file" "$HOME/${file}.backup.$(date +%Y%m%d)"
            echo "  已备份现有 $file"
        fi
        cp "$BACKUP_DIR/$file" "$HOME/"
        echo "  ✅ $file"
    fi
done

# 2. 恢复 Claude Code 配置
echo "🔧 [2/8] 恢复 Claude Code 配置..."
if [ -d "$BACKUP_DIR/.claude" ]; then
    mkdir -p ~/.claude
    cp -r "$BACKUP_DIR/.claude"/* ~/.claude/ 2>/dev/null || true
    echo "  ✅ ~/.claude"
fi
if [ -d "$BACKUP_DIR/.config/claude" ]; then
    mkdir -p ~/.config/claude
    cp -r "$BACKUP_DIR/.config/claude"/* ~/.config/claude/ 2>/dev/null || true
    echo "  ✅ ~/.config/claude"
fi

# 3. 恢复自定义脚本
echo "🔧 [3/8] 恢复自定义脚本..."
if [ -d "$BACKUP_DIR/bin" ]; then
    mkdir -p ~/bin
    cp -r "$BACKUP_DIR/bin"/* ~/bin/ 2>/dev/null || true
    chmod +x ~/bin/* 2>/dev/null || true
    echo "  ✅ ~/bin ($(ls ~/bin 2>/dev/null | wc -l) 个脚本)"
fi

# 4. 恢复 SSH 和 GPG
echo "🔧 [4/8] 恢复 SSH 和 GPG..."
if [ -d "$BACKUP_DIR/.ssh" ]; then
    mkdir -p ~/.ssh
    cp -r "$BACKUP_DIR/.ssh"/* ~/.ssh/ 2>/dev/null || true
    chmod 700 ~/.ssh
    chmod 600 ~/.ssh/* 2>/dev/null || true
    chmod 644 ~/.ssh/*.pub 2>/dev/null || true
    echo "  ✅ ~/.ssh"
fi
if [ -d "$BACKUP_DIR/.gnupg" ]; then
    cp -r "$BACKUP_DIR/.gnupg" ~/ && chmod 700 ~/.gnupg
    echo "  ✅ ~/.gnupg"
fi

# 5. 恢复 Git 配置
echo "🔧 [5/8] 恢复 Git 配置..."
for file in .gitconfig .gitignore_global .gitattributes; do
    if [ -f "$BACKUP_DIR/$file" ]; then
        cp "$BACKUP_DIR/$file" "$HOME/"
        echo "  ✅ $file"
    fi
done

# 6. 恢复包管理器配置
echo "🔧 [6/8] 恢复包管理器配置..."
for file in .npmrc .yarnrc .yarnrc.yml .pnpmrc; do
    if [ -f "$BACKUP_DIR/$file" ]; then
        cp "$BACKUP_DIR/$file" "$HOME/"
        echo "  ✅ $file"
    fi
done

# 7. 恢复开发工具配置
echo "🔧 [7/8] 恢复开发工具配置..."
if [ -d "$BACKUP_DIR/.config" ]; then
    mkdir -p ~/.config
    for tool in code cursor vim nvim tmux docker kubectl; do
        if [ -d "$BACKUP_DIR/.config/$tool" ]; then
            cp -r "$BACKUP_DIR/.config/$tool" ~/.config/
            echo "  ✅ $tool"
        fi
    done
fi

# 恢复 Vim/Neovim
for item in .vimrc .vim; do
    if [ -e "$BACKUP_DIR/$item" ]; then
        cp -r "$BACKUP_DIR/$item" "$HOME/"
        echo "  ✅ $item"
    fi
done

# 8. 恢复其他配置
echo "🔧 [8/8] 恢复其他配置..."
for cloud in .aws .azure .gcloud .aliyun .tencentcloud; do
    if [ -d "$BACKUP_DIR/$cloud" ]; then
        cp -r "$BACKUP_DIR/$cloud" "$HOME/"
        echo "  ✅ $cloud"
    fi
done

# 确保 PATH 包含 ~/bin
if ! grep -q 'export PATH="$HOME/bin:$PATH"' ~/.bashrc 2>/dev/null; then
    echo '' >> ~/.bashrc
    echo '# User custom scripts' >> ~/.bashrc
    echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc
    echo "  ✅ 已添加 ~/bin 到 PATH"
fi

echo ""
echo "========================================"
echo "  ✅ 配置恢复完成！"
echo "========================================"
echo ""
echo "下一步:"
echo "1. 重启终端或执行: source ~/.bashrc"
echo "2. 检查 michelle 脚本: which michelle"
echo "3. 验证 SSH: ssh -T git@github.com"
echo "4. 安装 NVM: curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash"
echo "5. 根据 $BACKUP_DIR/system-packages.txt 安装需要的系统包"
echo ""
echo "⚠️  重要提醒:"
echo "   系统级配置需要手动复制:"
echo "   sudo cp $BACKUP_DIR/system/etc/profile.d/claude_code_env.sh /etc/profile.d/"
echo ""

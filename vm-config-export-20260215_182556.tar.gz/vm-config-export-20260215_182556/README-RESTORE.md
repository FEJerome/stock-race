# VM 配置恢复说明

## 快速恢复步骤

### 1. 在 WSL2 中解压
```bash
cd ~
tar xzvf vm-config-export-XXXX.tar.gz
cd vm-config-export-XXXX
```

### 2. 运行自动导入脚本
```bash
./restore-to-wsl.sh
```

### 3. 手动处理系统级配置（需要 sudo）
```bash
sudo cp system/etc/profile.d/claude_code_env.sh /etc/profile.d/
```

### 4. 重新加载配置
```bash
source ~/.bashrc
# 或
exec bash
```

## 包含的配置
- ✅ Shell 配置 (.bashrc, .zshrc 等)
- ✅ Claude Code 完整配置 (~/.claude)
- ✅ 自定义脚本 (~/bin)
- ✅ SSH/GPG 密钥
- ✅ Git 配置
- ✅ NPM/Python 配置
- ✅ 开发工具配置
- ✅ 云服务 CLI 配置

## 注意事项
1. 检查并更新 API 密钥（如果已更换）
2. 重新安装 NVM 和 Node.js 版本
3. 根据需要安装系统包（参考 system-packages.txt）
4. WSL2 中 DISPLAY 变量可能需要调整

